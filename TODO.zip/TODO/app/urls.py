
from django.contrib import admin
from django.urls import path
from app.views import Home,Login,Signup,Add_todo,Logout,Delete_todo,Change_status

urlpatterns = [
    path('',Home ,name="homepage"),
    path('login',Login,name="loginpage"),
    path('signup',Signup,name="signpage"),
    path('add-todo', Add_todo , name="addtodopage"),
    path('logout' , Logout ),
    path('delete-todo/<int:id>',Delete_todo),
    path('change-status/<int:id>/<str:status>',Change_status)
]
